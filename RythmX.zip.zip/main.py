import rythmx

if __name__ == "__main__":
    rythmx.run_bot()