Simple music discord bot to play with some friends.
Also, my first project with Python.

This code was heavily based on the Youtube code MasterReach1 , where I express my thanks!

The bot has 4 commands: 

/play **url-here**

plays the music. For now, only works for Youtubr, however I plan to add Spotify and custom URLs.

/pause

Pauses it.

/resume

Resume the music.

/stop

Stops the bot entirely.


![RythmX Bot](image/RythmX)